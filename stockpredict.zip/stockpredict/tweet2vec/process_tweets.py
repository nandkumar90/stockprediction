'''
This file has scripts to consume a csv file with date and tweet as columns and appends
all tweets related to a date and writes into a file. This file is passed as input to tweet2vec_encoder
and embeddings are generated.
'''
import sys
import csv
import encode_char


def main(args):
    input_file = args[0]
    out_file_loc = args[1]
    dates_out_file_loc = args[2]

    out_file = open(out_file_loc, "w")
    dates_out_file = open(dates_out_file_loc, "w")
    dates_order = []
    prev_date = None
    tweets = []
    for line in open(input_file, "r"):
        date, text = line.split(",", 1)
        text = text.strip()
        if date == prev_date:
            tweets.append(text)
        # if prev_date is not none
        elif prev_date:
            out_file.write(" ".join(tweets))
            out_file.write("\n")
            dates_out_file.write(date)
            dates_out_file.write("\n")
            tweets = [text]
            prev_date = date
            dates_order.append(date)
        else:
            prev_date = date
            dates_out_file.write(date)
            dates_out_file.write("\n")
            # reinitializing tweets
            tweets = [text]
    out_file.write(" ".join(tweets))


if __name__ == '__main__':
    input_file = "/Users/demo/Downloads/tweet2vec-master/tweet2vec/tweets.csv"
    out_file_loc = "/Users/demo/Downloads/tweet2vec-master/misc/tweets_date.txt"
    dates_out_file_loc = "/Users/demo/Downloads/tweet2vec-master/misc/dates.txt"


    main(sys.argv[1:])
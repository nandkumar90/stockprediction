"""
This file reads the embeddings in numpy array and combines them.
"""

from os import listdir
folder_path = "result/"
import numpy as np
import pandas as pd
import csv

result = None
first = True

for file in listdir(folder_path):
    if file == "final_embeddings.txt" or file == "feature_vectors.csv":
        continue
    embeddings = np.genfromtxt(folder_path + file, delimiter=',')
    if first:
        result = embeddings
        first = False
        continue
    embeddings = np.genfromtxt(folder_path+file, delimiter=',')
    result = np.append(result, embeddings, axis=1)

result_pd = pd.DataFrame(result)

# reading dates file
with open("/Users/demo/Downloads/tweet2vec-master/misc/dates_Samsung.txt") as f:
    dates = f.read().splitlines()
result_pd['Date'] = dates

# reading stockes data
stocks_data_df = pd.read_csv("/Users/demo/Downloads/tweet2vec-master/tweet2vec/Merged-Stocks-Data.csv")
df_inner = pd.merge(result_pd, stocks_data_df, on='Date', how='inner')


df_inner.drop(['Date'], inplace=True, axis=1)


result = df_inner.as_matrix()
np.savetxt("result/final_embeddings.txt", result, delimiter=",", fmt='%s')

result = np.flip(result, 0)
num_of_samples = len(result)

num_of_days_look_back = 5

feature_vect_list = []

for i in range(num_of_samples):
    feature_vect = []
    if i + 5 > num_of_samples:
        break
    for j in range(i+1, i+5):
        feature_vect.extend(list(result[j,:]))
    # adding start stock price and close price
    feature_vect.append(result[i,-6])
    feature_vect.append(result[i, -1])
    feature_vect_list.append(feature_vect)

import random
random.shuffle(feature_vect_list)
indices = len(feature_vect_list[0])
header = range(indices)
feature_vect_list.insert(0, header)

with open("result/feature_vectors.csv", "w") as f:
    writer = csv.writer(f)
    writer.writerows(feature_vect_list)

#!/bin/bash
input_file="/Users/demo/Downloads/tweet2vec-master/tweet2vec/tweetdata/tweet_dataSamsung.csv"
out_file_loc="/Users/demo/Downloads/tweet2vec-master/misc/tweets_Samsung.txt"
dates_out_file_loc="/Users/demo/Downloads/tweet2vec-master/misc/dates_Samsung.txt"
python process_tweets.py $input_file $out_file_loc $dates_out_file_loc


#embeddings
# specify model path here
modelpath="best_model/"

# specify result path here
resultpath="result/embeddings_Samsung.txt"


# test
python encode_char.py $out_file_loc $modelpath $resultpath


input_file="/Users/demo/Downloads/tweet2vec-master/tweet2vec/tweetdata/tweet_dataSony.csv"
out_file_loc="/Users/demo/Downloads/tweet2vec-master/misc/tweets_Sony.txt"
dates_out_file_loc="/Users/demo/Downloads/tweet2vec-master/misc/dates_Sony.txt"
python process_tweets.py $input_file $out_file_loc $dates_out_file_loc


#embeddings
# specify model path here
modelpath="best_model/"

# specify result path here
resultpath="result/embeddings_Sony.txt"


# test
python encode_char.py $out_file_loc $modelpath $resultpath


input_file="/Users/demo/Downloads/tweet2vec-master/tweet2vec/tweetdata/tweet_dataXiaomi.csv"
out_file_loc="/Users/demo/Downloads/tweet2vec-master/misc/tweets_Xiaomi.txt"
dates_out_file_loc="/Users/demo/Downloads/tweet2vec-master/misc/dates_Xiaomi.txt"
python process_tweets.py $input_file $out_file_loc $dates_out_file_loc


#embeddings
# specify model path here
modelpath="best_model/"

# specify result path here
resultpath="result/embeddings_Sony.Xiaomi"


# test
python encode_char.py $out_file_loc $modelpath $resultpath
